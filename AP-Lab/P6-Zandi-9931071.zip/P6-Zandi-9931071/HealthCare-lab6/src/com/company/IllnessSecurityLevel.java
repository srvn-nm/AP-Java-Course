package com.company;

public enum IllnessSecurityLevel{
    LOW,MEDIUM,HIGH
}
