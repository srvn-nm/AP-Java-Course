package com.company;

public enum Illnesstype {
    ORTHOPEDIC,HEART,KIDNEY,WOMENREALTED,DIGESTIVE,ETC;
}

