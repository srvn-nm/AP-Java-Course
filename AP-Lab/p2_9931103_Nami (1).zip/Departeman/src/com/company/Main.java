package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Departeman name:");
        String name = input.nextLine();
        System.out.print("foundation date:");
        String date = input.nextLine();
        System.out.print("Department capacity:");
        int capacity = input.nextInt();
        Departeman departman = new Departeman(capacity,date,name);
        departman.toCreateDeparteman();
        departman.printDepartment();

    }
}
