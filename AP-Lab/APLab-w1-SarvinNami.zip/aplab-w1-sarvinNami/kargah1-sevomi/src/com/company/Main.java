package com.company;

public class Main {

    public static void main(String[] args) {
        for (char c : args[0].toCharArray()){
            System.out.println(c);
        }
    }
}
