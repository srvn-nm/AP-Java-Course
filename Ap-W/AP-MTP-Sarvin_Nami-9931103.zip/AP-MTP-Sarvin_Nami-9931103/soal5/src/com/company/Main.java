package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        int a1 , b1 , a2 , b2 , a3 = 0 , b3 = 0 ;
        Scanner input = new Scanner(System.in);
        a1 = input.nextInt();
        b1 = input.nextInt();
        a2 = input.nextInt();
        b2 = input.nextInt();
        char math;
        while (true){
            Scanner input1 = new Scanner(System.in);
            math = input1.next().charAt(0);
            if (math == '#'){
                break;
            }
            else if (math == '+'){
                a3 = a1 + a2;
                b3 = b1 + b2;
                if (b3 > 0){
                    System.out.println( a3 + "+" + b3 + "i");
                }
                else {
                    System.out.println( a3  + b3 + "i");
                }
            }
            else if (math == '*'){
                a3 = (a1*a2) - (b1*b2);
                b3 = (a1*b2) + (a2*b1);
                if (b3 > 0){
                    System.out.println( a3 + "+" + b3 + "i");
                }
                else {
                    System.out.println( a3  + b3 + "i");
                }
            }
            else if (math == '/'){
                a3 = ((a1*a2) + (b2*b1))/((a2*a2) + ((b2*b2)));
                b3 = ((b1*a2) - (a1*b2))/((a2*a2) + (b2*b2));
                if (b3 > 0){
                    System.out.println( a3 + "+" + b3 + "i");
                }
                else {
                    System.out.println( a3  + b3 + "i");
                }
            }
            else if (math == '-'){
                a3 = (a1) - (a2);
                b3 = (b1) - (b2);
                if (b3 > 0){
                    System.out.println( a3 + "+" + b3 + "i");
                }
                else {
                    System.out.println( a3  + b3 + "i");
                }
            }
        }
    }
}
