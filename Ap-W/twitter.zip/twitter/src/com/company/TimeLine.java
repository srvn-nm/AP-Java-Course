package com.company;

import java.util.ArrayList;
import java.util.Comparator;

public class TimeLine {
    public ArrayList<Account> users;
    public ArrayList<Twitt> allTwitts;
    /**
     * constructor
     */
    public TimeLine(){
        users = new ArrayList<Account>();
        allTwitts =new ArrayList<Twitt>();
    }
    public void showTimeLine(String username){
        //adding twitts, retwitts, replies and likes
        for (Account a:users) {
            if (a.getUserName().equals(username)){
                for (Account a2:a.following) {
                    allTwitts.addAll(a2.twitts);
                    for (Account a3:users) {
                        for (Twitt t:a3.twitts) {
                            for (String u:t.likes) {
                                if (a2.getUserName().equals(u))
                                    allTwitts.add(t);
                            }
                        }
                    }
                }
            }
        }
        allTwitts.sort(Comparator.comparing(Twitt::getTime));
    }
}
