package com.company;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class ObserverService {

    private ArrayList<Account> twitterUsers;//this array will save all sign up users

    /**
     * ObserverService constructor will make a new list of twitterUsers
     */

    public ObserverService(){
        twitterUsers = new ArrayList<>();
    }

    /**
     * this method will add new users ...
     * @param user
     */
    public void addNewMember(Account user){
        twitterUsers.add(user);
    }


    /**
     * print all Account will help  us
     to show all twitterUsers
     **/

    public void printAllAccount(){
        for
        (Account person : twitterUsers){

            System.out.println(person.toString
                    ()+"\n");
        }
    }

    /**
     *
     search will return your sepecefic Account
     (for following or reply or like)
     *
     return Account
     **/

    public Account search(Account user){
        Account searchedAccount = new Account("","","") ;
        printAllAccount();
        while (1==1){
            System.out.println("Please enter the username you want :");
            Scanner input = new Scanner(System.in);
            String searchingUserName = input.nextLine();
            if(searchingUserName(searchingUserName)){
                for(Account person : twitterUsers){
                    if(searchingUserName.equals(person.getUserName())){
                        searchedAccount = person;
                        while (true){
                            System.out.println("1)Follow\n2)Un follow\n3) "+searchedAccount.getUserName()+" Twitts\nEny Other Keyboard : Exit");
                            String choice = input.nextLine();
                            if(choice.equals("1")){
                                if(user.followingExist(searchedAccount)){
                                    System.out.println("You have already followed "+searchedAccount.getUserName()+" !");
                                }
                                else {
                                    user.setFollowing(searchedAccount);
                                }
                            }
                            else if(choice.equals("2")){
                                if(!user.followingExist(searchedAccount)){
                                    System.out.println("You have not followed "+searchedAccount.getUserName()+" already!");
                                }
                                else {
                                    user.Unfollow(searchedAccount);
                                }
                            }

                            else if(choice.equals("3")){
                                if(user.followingExist(searchedAccount)){
                                    int i = 1;
                                    for (Twitt t : user.twitts) {
                                        System.out.println(i+")"+t.toString());
                                        i++;
                                    }
                                }
                            }
                            else {
                                break;
                            }
                        }
                        break;
                    }
                }
                break;
            }
            else {
                System.out.println("Invalid Username -->\nDo you want to try it again?\n1) Yes\nother keys:No,Back to Menu");
                String choice = input.nextLine();
                if(!choice.equals("1")){
                    break;
                }
            }
        }

        return user;

    }

    /***
     * this method will check username in search
     * if its exist the returned condition is true
     * @param username
     * @return isCorrect
     */

    public boolean searchingUserName(String username){
        boolean isCorrect = false;
        for(Account person : twitterUsers){
            if(username.equals(person.getUserName())){
                isCorrect = true;
            }
        }
        return isCorrect;
    }

    /***
     * this method will help us to follow and unfollow users and show following users
     * @param user
     * @return
     */

    public Account mainMenu(Account user){

        while (1==1){
            System.out.println("\n1)search\n2)myFollowingList\n3)myFollowing Twitts\nEny Other Keyboard : Exit");
            Scanner input = new Scanner(System.in);
            String choice = input.nextLine();
            if(choice.equals("1")){
                user = search(user);
            }

            else if(choice.equals("2")){
                user.printFollowing();
            }

            else if(choice.equals("3")){

                // --> 5
            }

            else {
                break;
            }
        }
        return user;
    }

    /**
     * this method will help us to delete on specefic account
     * @param user --> deleted account
     */

    public void removeAccount(Account user){

        String usernameFollow = user.getUserName();
        Iterator<Account> it = twitterUsers.iterator();
        while (it.hasNext()) {
            Account account = (Account) it.next();
            if (usernameFollow.equals(account.getUserName())) {
                it.remove();

            }
        }
    }

}