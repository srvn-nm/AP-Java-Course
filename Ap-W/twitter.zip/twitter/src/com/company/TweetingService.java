package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class TweetingService {
    public ArrayList<Account> users;
    /**
     * constructor
     */
    public TweetingService(){
        users = new ArrayList<Account>();
    }
    /**
     * THIS METHOD WILL LIKE A TWITT.
     * @param t
     * @param username
     */
    public void Like(Twitt t,String username){
        t.like(username);
    }

    /**
     * a method to add a new twitt
     * @param un
     * @param text
     * @return t
     */
    public void twitt(String un,String text){
        for (Account a:users) {
            if (!a.getUserName().equals(un)){
                System.out.println("This username does not exist and should sign up first!");
                return;
            }
            for (Twitt t:a.twitts){
                if ((a.getUserName().equals(un)) && (t.getText().equals(text))){
                    System.out.println("This twitt was already added!");
                    return;
                }
            }
        }
        Twitt t = new Twitt();
        t.setUsername(un);
        t.setText(text);
        for (Account ac:users) {
            if (ac.getUserName().equals(un)){
                ac.twitts.add(t);
                return;
            }
        }
    }

    /**
     * This method will delete a twitt from a user's twitts.
     * @param un
     * @param text
     */
    public void deleteTwitt(String un, String text){
        boolean check = false;
        for (Account a:users) {
            if (!a.getUserName().equals(un)){
                System.out.println("This username does not exist and should sign up first!");
            }
            for (Twitt t:a.twitts){
                if ((a.getUserName().equals(un)) && (t.getText().equals(text))){
                    a.twitts.remove(t);
                    System.out.println("This twitt deleted successfully!");
                    check = true;
                }
            }
        }
        if (!check)
            System.out.println("This twitt was not found!");
    }

    /**
     * a method to retwitt someone's twitt
     * @param destinationUsername
     * @param originUsername
     * @param text
     */
    public void retwitt(String destinationUsername,String originUsername,String text){
        boolean check = false;
        for (Account oa:users) {
            for (Account da:users) {
                if (!oa.getUserName().equals(originUsername) || !da.getUserName().equals(destinationUsername)){
                    System.out.println("This username does not exist and should sign up first!");
                }
                for (Twitt t:oa.twitts){
                    if ((oa.getUserName().equals(destinationUsername)) && (t.getText().equals(text))){
                        Twitt t2 = new Twitt();
                        t2.setUsername(destinationUsername);
                        t2.setText("retwitted from:\n              "+originUsername+"\n"+t.getText());
                        da.twitts.add(t2);
                        System.out.println("This twitt retwitted successfully!");
                        check = true;
                    }
                }
            }
        }
        if (!check)
            System.out.println("This twitt was not found!");
    }

    /**
     * this method can be used when somebody wants to reply to somebody else
     * @param replyerUsername
     * @param repliedUsername
     * @param text
     */
    public void reply(String replyerUsername,String repliedUsername,String text){
        boolean check = false;
        Scanner in = new Scanner(System.in);
        for (Account oa:users) {
            for (Account da:users) {
                if (!oa.getUserName().equals(repliedUsername) || !da.getUserName().equals(replyerUsername)){
                    System.out.println("This username does not exist and should sign up first!");
                }
                for (Twitt t:oa.twitts){
                    if ((oa.getUserName().equals(replyerUsername)) && (t.getText().equals(text))){
                        Twitt t2 = new Twitt();
                        t2.setUsername(replyerUsername);
                        System.out.println("please type your reply:");
                        t2.setText(in.next());
                        t.addReply(t2);
                        System.out.println("Reply added successfully!");
                        check = true;
                    }
                }
            }
        }
        if (!check)
            System.out.println("This twitt was not found!");
    }
}