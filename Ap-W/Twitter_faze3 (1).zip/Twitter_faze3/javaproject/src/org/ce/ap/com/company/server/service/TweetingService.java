package org.ce.ap.com.company.server.service;

import org.ce.ap.com.company.server.model.Account;
import org.ce.ap.com.company.server.model.Tweet;

import java.util.ArrayList;
import java.util.Iterator;

/***
 * TweetingService class for managing user's actions like :
 *             tweets , retweets , replies and likes
 *
 *
 * @author  Sarvin Nami , Abtin Zandi
 * @version 3.0
 */
public class TweetingService {
    public ArrayList<Account> users;
    private TweetFile tweetFile;
    private AccountFile usersFileManger ;
    /**
     * constructor
     */
    public TweetingService(){
        users = new ArrayList<Account>();
        tweetFile = new TweetFile();
        usersFileManger = new AccountFile();
    }
    /**
     * THIS METHOD WILL LIKE A TWEET.
     * @param t
     * @param likerUsername
     * @param likedUsername
     */
    public Account Like(Tweet t, String likerUsername, String likedUsername){
        t.like(likerUsername);
        Account user = null;
        for (Account ac:users) {
            if (ac.getUserName().equals(likerUsername)){
                ac.likes.add(t);
                user = ac;
                break;
            }
        }
        return user;
    }

    /**
     * a method to add a new tweet
     * @param un
     * @param text
     * @return t
     */
    public Account tweet(String un, String text, ClientHandler clientHandler){
        for (Account a:users) {
            for (Tweet t:a.tweets){
                if ((a.getUserName().equals(un)) && (t.getText().equals(text))){
                    clientHandler.outputStream("This tweet was already added!");
                    return null;
                }
            }
        }
        Tweet t = new Tweet();
        t.setUsername(un);
        t.setText(text,clientHandler);
        Account user = null;
        for (Account ac:users) {
            if (ac.getUserName().equals(un)){
                ac.tweets.add(t);
                user = ac;
            }
        }
        tweetFile.writeNewTweetToFile(t);
        return user;
    }

    /**
     * This method will delete a tweet from a user's tweets.
     * @param un
     * @param text
     */
    public void deleteTweet(String un, String text, ClientHandler clientHandler){
        boolean check = false;
        for (Account a:users) {
            if (!a.getUserName().equals(un)){
                clientHandler.outputStream("This username does not exist and should sign up first!");
            }
            Iterator<Tweet> it = a.tweets.iterator();
            while (it.hasNext()){
                Tweet t = it.next();
                if ((a.getUserName().equals(un)) && (t.getText().equals(text))){
                    it.remove();
                    clientHandler.outputStream("This tweet deleted successfully!");
                    check = true;
                }
            }
        }
        if (!check)
            clientHandler.outputStream("This tweet was not found!");
        tweetFile.removeFile(un,text);
    }

    /**
     * a method to retwitt someone's twitt
     * @param destinationUsername
     * @param originUsername
     * @param text
     */
    public Account retweet(String destinationUsername, String originUsername, String text, ClientHandler clientHandler){
        boolean check = false;
        Tweet t2 = new Tweet();
        for (Account oa:users) {
            for (Account da:users) {
                for (Tweet t:oa.tweets){
                    if ((oa.getUserName().equals(originUsername)) && (t.getText().equals(text))){
                        t2.setUsername(destinationUsername);
                        t2.setText("retweeted from:\n              "+originUsername+"\n"+t.getText(),clientHandler);
                        da.tweets.add(t2);
                        clientHandler.outputStream("This tweet retweeted successfully!");
                        check = true;
                        break;
                    }
                }
            }
        }
        if (!check)
            clientHandler.outputStream("This tweet was not found!");
        Account user = null;
        for (Account ac:users) {
            if (ac.getUserName().equals(destinationUsername)){
                ac.tweets.add(t2);
                ac.retweets.add(t2);
                user = ac;
            }
        }
        tweetFile.writeNewTweetToFile(t2);
        return user;
    }

    /**
     * this method can be used when somebody wants to reply to somebody else
     * @param replyerUsername
     * @param repliedUsername
     * @param text
     */
    public Account reply(String replyerUsername,String repliedUsername,String text,ClientHandler clientHandler){
        boolean check = false;
        Tweet t2 = new Tweet();
        for (Account oa:users) {
            for (Tweet t:oa.tweets){
                if ((oa.getUserName().equals(repliedUsername)) && (t.getText().equals(text))){
                    t2.setUsername(replyerUsername);
                    clientHandler.outputStream("please type your reply:");
                    t2.setText(clientHandler.inputStream(),clientHandler);
                    t.addReply(t2,clientHandler);
                    clientHandler.outputStream("Reply added successfully!");
                    check = true;
                    break;
                }
            }
        }
        if (!check)
            clientHandler.outputStream("This tweet was not found!");
        Account user = null;
        for (Account ac:users) {
            if (ac.getUserName().equals(replyerUsername)){
                ac.tweets.add(t2);
                ac.replies.add(t2);
                user = ac;
            }
        }
        tweetFile.writeNewTweetToFile(t2);
        return user;
    }
    public void update() {
        users.clear();
        users.addAll(usersFileManger.AllUsers());

    }
}