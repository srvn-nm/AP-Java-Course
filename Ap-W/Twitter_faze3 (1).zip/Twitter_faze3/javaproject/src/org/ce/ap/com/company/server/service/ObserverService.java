package org.ce.ap.com.company.server.service;

import org.ce.ap.com.company.server.model.Account;
import org.ce.ap.com.company.server.model.TimeLine;
import org.ce.ap.com.company.server.model.Tweet;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * ObserverService class for search users' actions like :
 *             tweets , retweets , replies , likes
 *             and to add above to a specific tweet from specific user
 *
 *
 * @author Abtin Zandi , Sarvin Nami
 * @version 3.0
 */
public class ObserverService {

    private ArrayList<Account> twitterUsers;//this array will save all sign up users
    private TimeLine showingTable;
    private TweetingService tweetingService;
    private AccountFile usersFileManger;

    /**
     * ObserverService constructor will make a new list of twitterUsers
     */

    public ObserverService() {
        twitterUsers = new ArrayList<>();
        showingTable = new TimeLine();
        tweetingService = new TweetingService();
        usersFileManger = new AccountFile();
    }

    /**
     * this method will add new users ...
     *
     * @param user
     */
    public void addNewMember(Account user) {
        twitterUsers.add(user);
        showingTable.users.add(user);
        tweetingService.users.add(user);
    }


    /**
     * print all Account will help  us
     * to show all twitterUsers
     **/

    public void printAllAccount(ClientHandler clientHandler) {
        for
        (Account person : twitterUsers) {

            clientHandler.outputStream(person.toString() + "\n");
        }
    }

    /**
     * search will return your specific Account
     * (for following or reply or like)
     * <p>
     * return Account
     **/

    public Account search(Account user, ClientHandler clientHandler) {
        Account searchedAccount = new Account("", "", "");
        printAllAccount(clientHandler);
        while (1 == 1) {
            clientHandler.outputStream("Please enter the username you want :");
            String searchingUserName = clientHandler.inputStream();
            if (searchingUserName(searchingUserName)) {
                for (Account person : twitterUsers) {
                    if (searchingUserName.equals(person.getUserName())) {
                        searchedAccount = person;
                        while (true) {
                            clientHandler.outputStream("1)Follow\n2)Un follow\n3) " + searchedAccount.getUserName() + " Tweets\nEny Other Keyboard : Exit");
                            String choice = clientHandler.inputStream();
                            if (choice.equals("1")) {
                                if (user.followingExist(searchedAccount)) {
                                    clientHandler.outputStream("You have already followed " + searchedAccount.getUserName() + " !");
                                } else {
                                    user.setFollowing(searchedAccount);
                                }
                                showingTable.showTimeLine(user.getUserName(), clientHandler);
                                usersFileManger.newUser(user);
                                update();
                            } else if (choice.equals("2")) {
                                if (!user.followingExist(searchedAccount)) {
                                    clientHandler.outputStream("You have not followed " + searchedAccount.getUserName() + " already!");
                                } else {
                                    user.Unfollow(searchedAccount, clientHandler);
                                }
                                showingTable.showTimeLine(user.getUserName(), clientHandler);
                                usersFileManger.newUser(user);
                                update();
                            } else if (choice.equals("3")) {
                                if (user.followingExist(searchedAccount)) {
                                    int i = 1;
                                    for (Tweet t : searchedAccount.tweets) {
                                        clientHandler.outputStream(i + ")" + t.toString());
                                        i++;
                                    }
                                }
                                showingTable.showTimeLine(user.getUserName(), clientHandler);
                            } else {
                                break;
                            }
                        }
                        break;
                    }
                }
                break;
            } else {
                clientHandler.outputStream("Invalid Username -->\nDo you want to try it again?\n1) Yes\nother keys:No,Back to Menu");
                String choice = clientHandler.inputStream();
                if (!choice.equals("1")) {
                    break;
                }
            }
        }

        return user;

    }

    /***
     * this method will check username in search
     * if its exist the returned condition is true
     * @param username
     * @return isCorrect
     */

    public boolean searchingUserName(String username) {
        boolean isCorrect = false;
        for (Account person : twitterUsers) {
            if (username.equals(person.getUserName())) {
                isCorrect = true;
            }
        }
        return isCorrect;
    }

    /***
     * this method will help us to follow and unfollow users and show following users
     * @param user
     * @return
     */

    public Account mainMenu(Account user, ClientHandler clientHandler) {

        while (1 == 1) {
            clientHandler.outputStream("\n1)search\n2)my Following List\n3)my TimeLine\nEny Other Keyboard : Exit");
            showingTable.showTimeLine(user.getUserName(), clientHandler);
            String choice = clientHandler.inputStream();
            if (choice.equals("1")) {
                user = search(user, clientHandler);
                showingTable.showTimeLine(user.getUserName(), clientHandler);
                update();
            } else if (choice.equals("2")) {
                user.printFollowing();
                showingTable.showTimeLine(user.getUserName(), clientHandler);
            } else if (choice.equals("3")) {
                while (true) {
                    int index = 1;
                    showingTable.showTimeLine(user.getUserName(), clientHandler);
                    for (Tweet t : showingTable.allTweets) {
                        clientHandler.outputStream(index + ") " + t.toString());
                        index++;
                    }
                    clientHandler.outputStream("enter the number of the tweet you want to react:");
                    int num = Integer.parseInt(clientHandler.inputStream());
                    clientHandler.outputStream("\n1)Reply\n2)Retweet\n3)Like\nEny Other Keyboard : Exit");
                    String choice2 = clientHandler.inputStream();
                    if (choice2.equals("1")) {
                        Account account = tweetingService.reply(user.getUserName(), showingTable.allTweets.get(num - 1).getUsername(), showingTable.allTweets.get(num - 1).getText(), clientHandler);
                        usersFileManger.newUser(account);
                        update();
                        showingTable.showTimeLine(user.getUserName(), clientHandler);
                    } else if (choice2.equals("2")) {
                        Account account = tweetingService.retweet(user.getUserName(), showingTable.allTweets.get(num - 1).getUsername(), showingTable.allTweets.get(num - 1).getText(), clientHandler);
                        usersFileManger.newUser(account);
                        update();
                        showingTable.showTimeLine(user.getUserName(), clientHandler);
                    } else if (choice2.equals("3")) {
                        Account account = tweetingService.Like(showingTable.allTweets.get(num - 1), user.getUserName(), showingTable.allTweets.get(num - 1).getUsername());
                        usersFileManger.newUser(account);
                        update();
                        showingTable.showTimeLine(user.getUserName(), clientHandler);
                    } else break;
                }
                showingTable.showTimeLine(user.getUserName(), clientHandler);
            } else {
                break;
            }
        }
        return user;
    }

    /**
     * this method will help us to delete on specific account
     *
     * @param user --> deleted account
     */

    public void removeAccount(Account user) {

        String usernameFollow = user.getUserName();
        Iterator<Account> it = twitterUsers.iterator();
        while (it.hasNext()) {
            Account account = (Account) it.next();
            if (usernameFollow.equals(account.getUserName())) {
                it.remove();
                break;
            }
        }
        usersFileManger.removeFile(user);
        update();
    }

    public void update() {
        twitterUsers.clear();
        twitterUsers.addAll(usersFileManger.AllUsers());
        tweetingService.update();
    }
}
