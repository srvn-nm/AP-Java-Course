package org.ce.ap.com.company;


public class Main {

    public static void main(String[] args) {
        // Nothing ^-^
    }
}
