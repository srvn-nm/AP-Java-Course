package org.ce.ap.com.company.client;

import java.io.InputStream;

public class ConsoleViewService {

    public String consoleInputPrint(InputStream input){
        String showingMassage = "";

        try{
            byte[] bufferMenu = new byte[2048];
            int transfer = input.read(bufferMenu);
            showingMassage = new String(bufferMenu, 0, transfer);
        }

        catch (Exception error){
            error.printStackTrace();
        }

        if(showingMassage.equals("Over")){
            System.out.println("Have a nice day ^ _ ^\nsee you soon ...");
            return "Over";
        }
        else{
            System.out.println(showingMassage);
            if(showingMassage.contains("Error") || showingMassage.contains("--> \"Twitter\"")  || showingMassage.contains("user Detail:")){
                return "Input Free" ;
            }
            else{
                return "Continue";
            }

        }

    }
}
