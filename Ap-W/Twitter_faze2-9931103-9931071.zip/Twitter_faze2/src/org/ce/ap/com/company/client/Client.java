package org.ce.ap.com.company.client;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

/**
 * client class will help us to connect with server socket and our client can use Twitter Application  with this connection
 * @author Abtin zandi
 * @version 2.0  2021-12-20
 */

public class Client {

    public static void main(String[] args) {
        try(Socket clientSocket = new Socket("127.0.0.1",8080)) {

            //server massage to client --> Menu,tweets,search ...
            InputStream inputMenu = clientSocket.getInputStream();
            byte[] bufferMenu = new byte[2048];

            //out put choice --> menu server
            OutputStream outputs = clientSocket.getOutputStream();

            while (true) {

                int transfer = inputMenu.read(bufferMenu);
                String showingMassage = new String(bufferMenu, 0, transfer);

                if(showingMassage.equals("Over")){
                    System.out.println("Have a nice day ^ _ ^\nsee you soon ...");
                    break;
                }

                else if(showingMassage.contains("Error") || showingMassage.contains("--> \"Twitter\"")  || showingMassage.contains("user Detail:")){

                    System.out.println(showingMassage);

                }

                else {
                    System.out.println(showingMassage);
                    //client response ...
                    Scanner input = new Scanner(System.in);
                    String inputMassage = input.nextLine();
                    outputs.write(inputMassage.getBytes());
                }

            }

        }catch (Exception runTimeError){
            runTimeError.printStackTrace();
        }

    }
}