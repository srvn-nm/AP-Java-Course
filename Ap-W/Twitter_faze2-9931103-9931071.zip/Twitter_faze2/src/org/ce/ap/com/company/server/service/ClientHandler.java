package org.ce.ap.com.company.server.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import org.ce.ap.com.company.server.model.*;
import org.ce.ap.com.company.server.service.*;

public class ClientHandler implements Runnable {

    private final Socket connectionSocket;
    private final int clientNum;
    private InputStream in;
    private OutputStream out;

    public ClientHandler(Socket connectionSocket, int clientNum , InputStream in, OutputStream out) {
        this.connectionSocket = connectionSocket;
        this.clientNum=clientNum;
        this.in=in;
        this.out=out;
    }

    /**
     * this method will help us to use our clases and transfer details with users and client class
     * @return string for client side
     */
    public String inputStream(){
        String receivedMessage;
        try {
            byte[] buffer = new byte[2048];
            int read = in.read(buffer);
            receivedMessage = new String(buffer, 0, read);
        } catch (Exception e) {
            receivedMessage = "error";
            e.printStackTrace();
        }
        return receivedMessage;
    }

    public void outputStream(String outputs) {
        try {
            out.write(outputs.getBytes());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {

            byte[] buffer = new byte[2048];
            ArrayList<String> savedLine = new ArrayList<String>();
            int index = 0;

            TwitterService service = new TwitterService();

            while (true) {
                outputStream("Twitter :\n1) Log In\n2) Sign Up\nEny Other Keyboard : EXIT");
                String receivedMessage = inputStream();

                System.out.println("RECV from "+clientNum+": " + receivedMessage);
                savedLine.add(receivedMessage);
                //out.write(savedLine.get(index).getBytes());
                System.out.println("SENT to "+clientNum+": " + savedLine);

                if(receivedMessage.equals("1")){
                    service.serverLogIn(this);
                }

                else if(receivedMessage.equals("2")){
                    service.newMember(this);
                }

                else{
                    String exit = "Over";
                    out.write(exit.getBytes());
                    break;
                }
                index++;
                Thread.sleep(2000);

            }
            System.out.print("All messages sent.\nClosing client ... ");
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            try {
                connectionSocket.close();
            } catch (IOException error) {
                error.printStackTrace();
            }
        }
    }
}